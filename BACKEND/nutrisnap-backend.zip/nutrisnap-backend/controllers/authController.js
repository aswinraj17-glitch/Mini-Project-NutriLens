const jwt = require("jsonwebtoken");
const { validationResult } = require("express-validator");
const User = require("../models/User");
const { targetForGoal } = require("../utils/calorieCalc");

const sign = (id) =>
  jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || "7d" });

exports.register = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

    const { name, email, password, goal } = req.body;
    const exists = await User.findOne({ email });
    if (exists) return res.status(409).json({ message: "Email already registered" });

    const user = await User.create({
      name,
      email,
      password,
      goal: goal || "maintenance",
      dailyCalorieTarget: targetForGoal(goal),
    });

    res.status(201).json({
      token: sign(user._id),
      user: { id: user._id, name: user.name, email: user.email, goal: user.goal,
              dailyCalorieTarget: user.dailyCalorieTarget },
    });
  } catch (err) { next(err); }
};

exports.login = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user || !(await user.matchPassword(password))) {
      return res.status(401).json({ message: "Invalid email or password" });
    }
    res.json({
      token: sign(user._id),
      user: { id: user._id, name: user.name, email: user.email, goal: user.goal,
              dailyCalorieTarget: user.dailyCalorieTarget },
    });
  } catch (err) { next(err); }
};

exports.me = async (req, res) => res.json({ user: req.user });
