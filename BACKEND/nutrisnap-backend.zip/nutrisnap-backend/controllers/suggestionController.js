// Static catalog (could be replaced with DB-backed Suggestion model entries)
const CATALOG = {
  low: [
    { name: "Oats & Banana Bowl", nutrients: { calories: 350, protein: 12, carbs: 60, fats: 6 }, estimatedCost: 1.5, image: "🥣" },
    { name: "Dal & Brown Rice", nutrients: { calories: 420, protein: 18, carbs: 70, fats: 6 }, estimatedCost: 2.0, image: "🍛" },
    { name: "Egg Bhurji & Toast", nutrients: { calories: 380, protein: 22, carbs: 30, fats: 18 }, estimatedCost: 2.2, image: "🍳" },
  ],
  medium: [
    { name: "Grilled Chicken Salad", nutrients: { calories: 480, protein: 42, carbs: 22, fats: 18 }, estimatedCost: 5.0, image: "🥗" },
    { name: "Paneer Tikka Wrap", nutrients: { calories: 510, protein: 28, carbs: 45, fats: 22 }, estimatedCost: 4.5, image: "🌯" },
    { name: "Avocado Toast & Eggs", nutrients: { calories: 460, protein: 22, carbs: 35, fats: 25 }, estimatedCost: 4.8, image: "🥑" },
  ],
  high: [
    { name: "Salmon & Quinoa", nutrients: { calories: 620, protein: 45, carbs: 50, fats: 24 }, estimatedCost: 9.5, image: "🐟" },
    { name: "Steak & Sweet Potato", nutrients: { calories: 720, protein: 52, carbs: 48, fats: 30 }, estimatedCost: 12.0, image: "🥩" },
    { name: "Shrimp Stir-fry", nutrients: { calories: 540, protein: 38, carbs: 40, fats: 18 }, estimatedCost: 10.0, image: "🍤" },
  ],
};

const GOAL_BIAS = {
  weight_loss: (m) => m.nutrients.calories <= 500,
  weight_gain: (m) => m.nutrients.calories >= 450,
  muscle_gain: (m) => m.nutrients.protein >= 25,
  maintenance: () => true,
};

exports.getSuggestions = (req, res) => {
  const { goal = "maintenance", budget = "medium" } = req.query;
  const list = CATALOG[budget] || CATALOG.medium;
  const filter = GOAL_BIAS[goal] || GOAL_BIAS.maintenance;
  const meals = list.filter(filter);
  res.json({ goal, budget, meals: meals.length ? meals : list });
};
