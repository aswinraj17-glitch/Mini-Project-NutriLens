const DailyLog = require("../models/DailyLog");
const { todayKey } = require("../utils/calorieCalc");

exports.daily = async (req, res, next) => {
  try {
    if (req.params.userId !== String(req.user._id))
      return res.status(403).json({ message: "Forbidden" });
    const date = req.query.date || todayKey();
    const log = await DailyLog.findOne({ userId: req.params.userId, date });
    res.json({
      date,
      totals: log || { totalCalories: 0, protein: 0, carbs: 0, fats: 0, mealsCount: 0 },
      target: req.user.dailyCalorieTarget,
    });
  } catch (err) { next(err); }
};

exports.weekly = async (req, res, next) => {
  try {
    if (req.params.userId !== String(req.user._id))
      return res.status(403).json({ message: "Forbidden" });
    const days = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      days.push(todayKey(d));
    }
    const logs = await DailyLog.find({
      userId: req.params.userId,
      date: { $in: days },
    });
    const map = Object.fromEntries(logs.map((l) => [l.date, l]));
    const data = days.map((date) => ({
      date,
      totalCalories: map[date]?.totalCalories || 0,
      protein: map[date]?.protein || 0,
      carbs: map[date]?.carbs || 0,
      fats: map[date]?.fats || 0,
    }));
    res.json({ week: data, target: req.user.dailyCalorieTarget });
  } catch (err) { next(err); }
};
