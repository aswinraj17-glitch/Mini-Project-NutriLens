const Meal = require("../models/Meal");
const DailyLog = require("../models/DailyLog");
const { detectFood } = require("../utils/aiDetect");
const { todayKey } = require("../utils/calorieCalc");

exports.uploadMeal = async (req, res, next) => {
  try {
    const { mealType, manualInput, calories, protein, carbs, fats } = req.body;
    if (!mealType) return res.status(400).json({ message: "mealType is required" });

    let imageUrl = null;
    if (req.file) {
      imageUrl = req.file.path?.startsWith("http")
        ? req.file.path
        : `/uploads/${req.file.filename}`;
    }

    let detectedFoods = [];
    let nutrients = {
      calories: Number(calories) || 0,
      protein: Number(protein) || 0,
      carbs: Number(carbs) || 0,
      fats: Number(fats) || 0,
    };
    let lowConfidence = false;

    if (req.file && !manualInput) {
      const ai = await detectFood(req.file.path);
      detectedFoods = ai.foods;
      lowConfidence = ai.lowConfidence;
      if (!lowConfidence) nutrients = ai.nutrients;
    }

    if (lowConfidence && !manualInput && !calories) {
      return res.status(200).json({
        needsManualInput: true,
        message: "AI confidence low. Please provide details manually.",
        detectedFoods,
        imageUrl,
      });
    }

    const meal = await Meal.create({
      userId: req.user._id,
      mealType,
      imageUrl,
      detectedFoods,
      manualInput,
      nutrients,
    });

    // Update daily log
    const date = todayKey();
    await DailyLog.findOneAndUpdate(
      { userId: req.user._id, date },
      {
        $inc: {
          totalCalories: nutrients.calories,
          protein: nutrients.protein,
          carbs: nutrients.carbs,
          fats: nutrients.fats,
          mealsCount: 1,
        },
      },
      { upsert: true, new: true }
    );

    res.status(201).json({ meal });
  } catch (err) { next(err); }
};

exports.getUserMeals = async (req, res, next) => {
  try {
    if (req.params.userId !== String(req.user._id))
      return res.status(403).json({ message: "Forbidden" });
    const meals = await Meal.find({ userId: req.params.userId }).sort({ createdAt: -1 }).limit(100);
    res.json({ meals });
  } catch (err) { next(err); }
};
