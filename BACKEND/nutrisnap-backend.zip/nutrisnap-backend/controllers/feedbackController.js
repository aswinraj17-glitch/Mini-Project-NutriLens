const DailyLog = require("../models/DailyLog");
const { todayKey } = require("../utils/calorieCalc");

exports.feedback = async (req, res, next) => {
  try {
    if (req.params.userId !== String(req.user._id))
      return res.status(403).json({ message: "Forbidden" });

    const date = req.query.date || todayKey();
    const log = await DailyLog.findOne({ userId: req.params.userId, date });
    const target = req.user.dailyCalorieTarget;

    const totals = log || { totalCalories: 0, protein: 0, carbs: 0, fats: 0 };
    const insights = [];

    // Protein target ~ 1g per kcal/30
    const proteinTarget = Math.round(target / 30);
    if (totals.protein < proteinTarget * 0.7) {
      insights.push({
        type: "warning",
        title: "Low protein intake",
        message: `You've had ${totals.protein}g of protein. Aim for ~${proteinTarget}g.`,
        suggestion: "Add eggs, dal, paneer, or grilled chicken.",
      });
    }
    if (totals.fats > target * 0.13) {
      insights.push({
        type: "warning",
        title: "High fat consumption",
        message: `Fat intake is above the recommended range.`,
        suggestion: "Swap fried foods for grilled or baked options.",
      });
    }
    if (totals.totalCalories < target * 0.6) {
      insights.push({
        type: "info",
        title: "Calorie deficit",
        message: `You're ${target - totals.totalCalories} kcal under target.`,
        suggestion: "Add a balanced snack like nuts, fruit, or yogurt.",
      });
    }
    if (totals.totalCalories > target * 1.15) {
      insights.push({
        type: "warning",
        title: "Calorie excess",
        message: `You've exceeded your target by ${totals.totalCalories - target} kcal.`,
        suggestion: "Choose lighter options for the rest of the day.",
      });
    }
    if (!insights.length) {
      insights.push({
        type: "success",
        title: "Great job!",
        message: "Your nutrition is on track today.",
        suggestion: "Keep up the balanced eating!",
      });
    }

    res.json({ date, target, totals, insights });
  } catch (err) { next(err); }
};
