const User = require("../models/User");
const { targetForGoal } = require("../utils/calorieCalc");

exports.setGoal = async (req, res, next) => {
  try {
    const { goal } = req.body;
    const allowed = ["weight_loss", "weight_gain", "muscle_gain", "maintenance"];
    if (!allowed.includes(goal)) return res.status(400).json({ message: "Invalid goal" });

    const target = targetForGoal(goal);
    const user = await User.findByIdAndUpdate(
      req.user._id,
      { goal, dailyCalorieTarget: target },
      { new: true }
    ).select("-password");

    res.json({ user });
  } catch (err) { next(err); }
};

exports.getGoal = async (req, res, next) => {
  try {
    if (req.params.userId !== String(req.user._id))
      return res.status(403).json({ message: "Forbidden" });
    res.json({
      goal: req.user.goal,
      dailyCalorieTarget: req.user.dailyCalorieTarget,
    });
  } catch (err) { next(err); }
};
