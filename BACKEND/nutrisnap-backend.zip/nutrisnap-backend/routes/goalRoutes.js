const router = require("express").Router();
const { protect } = require("../middleware/auth");
const { setGoal, getGoal } = require("../controllers/goalController");

router.post("/set", protect, setGoal);
router.get("/:userId", protect, getGoal);

module.exports = router;
