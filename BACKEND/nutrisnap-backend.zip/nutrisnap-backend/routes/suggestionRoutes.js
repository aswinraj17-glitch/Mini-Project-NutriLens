const router = require("express").Router();
const { getSuggestions } = require("../controllers/suggestionController");

router.get("/", getSuggestions);

module.exports = router;
