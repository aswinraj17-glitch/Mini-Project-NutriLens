const router = require("express").Router();
const { protect } = require("../middleware/auth");
const { daily, weekly } = require("../controllers/nutritionController");

router.get("/:userId/daily", protect, daily);
router.get("/:userId/weekly", protect, weekly);

module.exports = router;
