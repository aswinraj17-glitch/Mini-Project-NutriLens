const router = require("express").Router();
const { protect } = require("../middleware/auth");
const { feedback } = require("../controllers/feedbackController");

router.get("/:userId", protect, feedback);

module.exports = router;
