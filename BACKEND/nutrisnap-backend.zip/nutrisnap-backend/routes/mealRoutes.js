const router = require("express").Router();
const { protect } = require("../middleware/auth");
const upload = require("../middleware/upload");
const { uploadMeal, getUserMeals } = require("../controllers/mealController");

router.post("/upload", protect, upload.single("image"), uploadMeal);
router.get("/:userId", protect, getUserMeals);

module.exports = router;
