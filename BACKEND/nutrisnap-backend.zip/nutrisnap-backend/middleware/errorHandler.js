module.exports = (err, _req, res, _next) => {
  console.error("🔥 Error:", err.message);
  const status = err.statusCode || 500;
  res.status(status).json({
    message: err.message || "Server error",
    ...(process.env.NODE_ENV !== "production" && { stack: err.stack }),
  });
};
