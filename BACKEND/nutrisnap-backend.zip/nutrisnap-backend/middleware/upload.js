const multer = require("multer");
const path = require("path");
const fs = require("fs");
const { CloudinaryStorage } = require("multer-storage-cloudinary");
const { cloudinary, isConfigured } = require("../config/cloudinary");

const uploadDir = path.join(__dirname, "..", "uploads");
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const localStorage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => {
    const unique = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, unique + path.extname(file.originalname));
  },
});

const cloudStorage = isConfigured()
  ? new CloudinaryStorage({
      cloudinary,
      params: { folder: "nutrisnap", allowed_formats: ["jpg", "jpeg", "png", "webp"] },
    })
  : null;

const fileFilter = (_req, file, cb) => {
  const ok = /jpeg|jpg|png|webp/.test(file.mimetype);
  cb(ok ? null : new Error("Only image files allowed"), ok);
};

const upload = multer({
  storage: cloudStorage || localStorage,
  fileFilter,
  limits: { fileSize: 10 * 1024 * 1024 },
});

module.exports = upload;
