const mongoose = require("mongoose");

const suggestionSchema = new mongoose.Schema(
  {
    goal: {
      type: String,
      enum: ["weight_loss", "weight_gain", "muscle_gain", "maintenance"],
      required: true,
    },
    budget: { type: String, enum: ["low", "medium", "high"], required: true },
    meals: [
      {
        name: String,
        nutrients: {
          calories: Number,
          protein: Number,
          carbs: Number,
          fats: Number,
        },
        estimatedCost: Number,
        image: String,
      },
    ],
  },
  { timestamps: true }
);

module.exports = mongoose.model("Suggestion", suggestionSchema);
