const mongoose = require("mongoose");

const mealSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
    mealType: {
      type: String,
      enum: ["breakfast", "lunch", "snacks", "dinner"],
      required: true,
    },
    imageUrl: { type: String },
    detectedFoods: [
      {
        name: String,
        portion: String,
        confidence: Number,
      },
    ],
    manualInput: { type: String },
    nutrients: {
      calories: { type: Number, default: 0 },
      protein: { type: Number, default: 0 },
      carbs: { type: Number, default: 0 },
      fats: { type: Number, default: 0 },
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Meal", mealSchema);
