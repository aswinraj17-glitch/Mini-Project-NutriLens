const GOAL_TARGETS = {
  weight_loss: 1600,
  weight_gain: 2800,
  muscle_gain: 3000,
  maintenance: 2200,
};

const targetForGoal = (goal) => GOAL_TARGETS[goal] || GOAL_TARGETS.maintenance;

const todayKey = (d = new Date()) => d.toISOString().slice(0, 10);

module.exports = { GOAL_TARGETS, targetForGoal, todayKey };
