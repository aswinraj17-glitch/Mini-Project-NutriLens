const TARGETS = { loss: 1600, gain: 2800, muscle: 3000, maintain: 2200 };
exports.calorieTargetForGoal = (goal) => TARGETS[goal] || 2200;
