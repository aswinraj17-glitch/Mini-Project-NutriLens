// Mock AI food detection. Replace with real AI provider (e.g. Clarifai, LogMeal, OpenAI Vision).
// Returns { foods: [{name, portion, confidence}], confidence, nutrients }

const SAMPLE = [
  { name: "Grilled Chicken", portion: "150g", calories: 250, protein: 40, carbs: 0, fats: 9 },
  { name: "Quinoa", portion: "1 cup", calories: 220, protein: 8, carbs: 39, fats: 4 },
  { name: "Mixed Salad", portion: "1 bowl", calories: 70, protein: 3, carbs: 10, fats: 2 },
  { name: "Oatmeal", portion: "1 cup", calories: 300, protein: 10, carbs: 55, fats: 5 },
  { name: "Paneer Tikka", portion: "100g", calories: 280, protein: 18, carbs: 6, fats: 22 },
  { name: "Dal", portion: "1 cup", calories: 180, protein: 12, carbs: 28, fats: 2 },
];

async function detectFood(_imagePath) {
  // Pick 1–2 random sample foods
  const pick = [...SAMPLE].sort(() => 0.5 - Math.random()).slice(0, 2);
  const confidence = +(0.4 + Math.random() * 0.6).toFixed(2); // 0.4–1.0

  const foods = pick.map((f) => ({
    name: f.name,
    portion: f.portion,
    confidence: +(0.5 + Math.random() * 0.5).toFixed(2),
  }));

  const nutrients = pick.reduce(
    (acc, f) => ({
      calories: acc.calories + f.calories,
      protein: acc.protein + f.protein,
      carbs: acc.carbs + f.carbs,
      fats: acc.fats + f.fats,
    }),
    { calories: 0, protein: 0, carbs: 0, fats: 0 }
  );

  return { foods, confidence, nutrients, lowConfidence: confidence < 0.6 };
}

module.exports = { detectFood };
