const router = require("express").Router();
const auth = require("../middleware/auth");
const Meal = require("../models/Meal");
const DailyLog = require("../models/DailyLog");

function ymd(d) { return d.toISOString().slice(0, 10); }

async function summarizeDay(userId, dateStr) {
  const start = new Date(dateStr);
  const end = new Date(start); end.setDate(end.getDate() + 1);
  const meals = await Meal.find({ user: userId, date: { $gte: start, $lt: end } });
  const totals = meals.reduce((a, m) => ({
    calories: a.calories + (m.calories || 0),
    protein: a.protein + (m.protein || 0),
    carbs: a.carbs + (m.carbs || 0),
    fat: a.fat + (m.fat || 0),
  }), { calories: 0, protein: 0, carbs: 0, fat: 0 });
  const log = await DailyLog.findOne({ user: userId, date: dateStr });
  return { date: dateStr, totals, water: log?.water || 0, mealsCount: meals.length };
}

router.get("/today", auth, async (req, res) => {
  res.json(await summarizeDay(req.userId, ymd(new Date())));
});

router.get("/weekly", auth, async (req, res) => {
  const days = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(); d.setDate(d.getDate() - i);
    days.push(await summarizeDay(req.userId, ymd(d)));
  }
  res.json({ days });
});

router.post("/water", auth, async (req, res) => {
  const liters = Number(req.body.liters || 0);
  const date = ymd(new Date());
  const log = await DailyLog.findOneAndUpdate(
    { user: req.userId, date },
    { $inc: { water: liters } },
    { new: true, upsert: true }
  );
  res.json({ log });
});

module.exports = router;
