const router = require("express").Router();
const auth = require("../middleware/auth");
const User = require("../models/User");

router.put("/goal", auth, async (req, res) => {
  const { goal, dailyTargets } = req.body || {};
  const update = {};
  if (goal) update.goal = goal;
  if (dailyTargets) update.dailyTargets = dailyTargets;
  const user = await User.findByIdAndUpdate(req.userId, update, { new: true }).select("-passwordHash");
  res.json({ user });
});

module.exports = router;
