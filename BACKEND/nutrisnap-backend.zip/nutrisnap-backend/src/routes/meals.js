const router = require("express").Router();
const path = require("path");
const fs = require("fs");
const multer = require("multer");
const auth = require("../middleware/auth");
const Meal = require("../models/Meal");

const uploadDir = path.join(__dirname, "..", "..", "uploads");
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname) || ".jpg";
    cb(null, `${Date.now()}-${Math.random().toString(36).slice(2)}${ext}`);
  },
});
const upload = multer({ storage, limits: { fileSize: 8 * 1024 * 1024 } });

// Upload meal image (mock nutrition estimate — replace with real ML later)
router.post("/upload", auth, upload.single("image"), async (req, res) => {
  if (!req.file) return res.status(400).json({ message: "image required" });
  const type = req.body.type || "snack";
  const host = `${req.protocol}://${req.get("host")}`;
  const imageUrl = `${host}/uploads/${req.file.filename}`;

  // Mock estimated nutrition — swap with AI later
  const meal = await Meal.create({
    user: req.userId,
    name: "Detected meal",
    type,
    imageUrl,
    calories: 350 + Math.floor(Math.random() * 300),
    protein: 15 + Math.floor(Math.random() * 25),
    carbs: 30 + Math.floor(Math.random() * 50),
    fat: 8 + Math.floor(Math.random() * 20),
  });
  res.json({ meal });
});

router.post("/", auth, async (req, res) => {
  const meal = await Meal.create({ ...req.body, user: req.userId });
  res.json({ meal });
});

router.get("/", auth, async (req, res) => {
  const filter = { user: req.userId };
  if (req.query.date) {
    const start = new Date(req.query.date);
    const end = new Date(start);
    end.setDate(end.getDate() + 1);
    filter.date = { $gte: start, $lt: end };
  }
  const meals = await Meal.find(filter).sort({ date: -1 });
  res.json({ meals });
});

router.delete("/:id", auth, async (req, res) => {
  await Meal.deleteOne({ _id: req.params.id, user: req.userId });
  res.json({ ok: true });
});

module.exports = router;
