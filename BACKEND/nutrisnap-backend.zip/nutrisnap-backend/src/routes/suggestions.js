const router = require("express").Router();
const auth = require("../middleware/auth");
const User = require("../models/User");
const Meal = require("../models/Meal");

router.get("/", auth, async (req, res) => {
  const user = await User.findById(req.userId);
  const start = new Date(); start.setHours(0, 0, 0, 0);
  const meals = await Meal.find({ user: req.userId, date: { $gte: start } });
  const totals = meals.reduce((a, m) => ({
    calories: a.calories + (m.calories || 0),
    protein: a.protein + (m.protein || 0),
  }), { calories: 0, protein: 0 });

  const tips = [];
  const target = user?.dailyTargets || { calories: 2000, protein: 100 };
  if (totals.calories < target.calories * 0.5)
    tips.push("You're under half your calorie goal — add a balanced meal.");
  if (totals.protein < target.protein * 0.5)
    tips.push("Protein is low — try eggs, lentils, chicken or tofu.");
  if (!tips.length) tips.push("You're on track. Keep hydrated and add veggies to your next meal.");

  res.json({ suggestions: tips.map((t, i) => ({ id: i + 1, text: t })) });
});

module.exports = router;
