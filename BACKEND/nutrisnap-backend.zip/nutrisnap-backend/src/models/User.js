const mongoose = require("mongoose");

const UserSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true, lowercase: true },
    passwordHash: { type: String, required: true },
    goal: { type: String, default: "maintain" },
    dailyTargets: {
      calories: { type: Number, default: 2000 },
      protein: { type: Number, default: 100 },
      carbs: { type: Number, default: 250 },
      fat: { type: Number, default: 70 },
      water: { type: Number, default: 2.5 },
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("User", UserSchema);
